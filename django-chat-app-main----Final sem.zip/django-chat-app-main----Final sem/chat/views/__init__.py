from .chat_view import *
from .friends_view import *
from .home_view import *
from .user_view import *
