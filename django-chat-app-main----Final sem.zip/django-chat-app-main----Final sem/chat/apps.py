from django.apps import AppConfig


class chatConfig(AppConfig):
    name = 'chat'
